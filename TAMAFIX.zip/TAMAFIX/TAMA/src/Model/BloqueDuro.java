package Model;

public class BloqueDuro extends Bloque{

	public BloqueDuro() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int getDureza() {
		return 3;
	}
}
