package Model;

public class Egg implements State {
	
	public int getDecrementoVida() {
		return 0;
	}
	public int getDecrementoComida() {
		return 0;
	}
	public String getNombreEvo() {
		return "Egg";
	}	
}
