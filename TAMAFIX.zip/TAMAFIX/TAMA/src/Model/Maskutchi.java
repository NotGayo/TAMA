package Model;

public class Maskutchi implements State{
	
	public int getDecrementoVida() {
		return -3;
	}
	public int getDecrementoComida() {
		return -14;
	}
	public String getNombreEvo() {
		return "Maskutchi";
	}
		
}

