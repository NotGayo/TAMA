package Model;

public class Mametchi implements State{
	
	public int getDecrementoVida() {
		return -1;
	}
	public int getDecrementoComida() {
		return -1;
	}
	public String getNombreEvo() {
		return "Mametchi";
	}
}

