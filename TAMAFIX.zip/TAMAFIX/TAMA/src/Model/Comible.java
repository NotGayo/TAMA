package Model;

public interface Comible {
	
	public int getValorComida();
	public int getValorVida();
	public void consumirElementos();
	public String getNombre();
}
