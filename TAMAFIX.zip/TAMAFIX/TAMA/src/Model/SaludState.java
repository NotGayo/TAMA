package Model;

public interface SaludState {
	public int getDecrementoVida();
	public int getDecrementoComida();
	public int getAumentoPuntuacion();
	public String getNombreEvo();
}
