package Model;

public class BloqueMedio extends Bloque {
	public BloqueMedio() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int getDureza() {
		return 2;
	}
}
