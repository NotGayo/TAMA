package Model;



/**
 * Interfaz para la fbrica de bloques.
 */
public interface BloqueFactoryInter {
    Bloque crearBloque();
}
