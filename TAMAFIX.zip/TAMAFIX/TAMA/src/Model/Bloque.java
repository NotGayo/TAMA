package Model;
import java.util.Random;
public abstract class Bloque {
    public Bloque() {

    }

    public int getDureza(){
       return 0;
    }
}
