package Model;

public class BloqueBlando extends Bloque{
	
	
	public BloqueBlando() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int getDureza() {
		return 1;
	}
}
