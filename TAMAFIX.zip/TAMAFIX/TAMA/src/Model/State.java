package Model;

public interface State {
	public int getDecrementoVida();
	public int getDecrementoComida();
	public String getNombreEvo();
}
