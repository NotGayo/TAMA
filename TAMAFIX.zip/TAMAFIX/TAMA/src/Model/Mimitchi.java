package Model;

public class Mimitchi implements State{
	
	public int getDecrementoVida() {
		return -7;
	}
	public int getDecrementoComida() {
		return -7;
	}
	public String getNombreEvo() {
		return "Mimitchi";
	}
}

